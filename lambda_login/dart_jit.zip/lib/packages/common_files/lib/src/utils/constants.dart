enum FilterEhSincronizado {todos, sincronizados, naoSincronizados}
enum FilterEhCancelado {todos, cancelados, naoCancelados}
enum FilterEhDeletado {todos, deletados, naoDeletados}
enum StatusLogin {loginOk, usuarioSenhaInvalida, usuarioJaCadastrado, usuarioBloqueado}
const String accessKeyId = 'AKIAJ4EUQPYS24CB35GA';
const String secretKeyId = 'D8/qdMHWqQmflMtXScwXevg5F79mvmwQ92XE91Rd';
const String region = 'sa-east-1';
const String s3Endpoint = 'https://fluggy-images.s3-sa-east-1.amazonaws.com';
final String hasuraUrl = "http://ec2-54-233-64-9.sa-east-1.compute.amazonaws.com:8080/v1/graphql";
final String postgresUrl = "graphqldb.clb0ejaw4ykt.sa-east-1.rds.amazonaws.com";
final String postgresUsername = "zumaadmin";
final String postgresPassword = "newappzuma2211";
final String postgresDatabase = "postgres";
